//
//  Bruxism.hpp
//  FeverDream
//
//  Created by Jake on 29/03/2023.
//

#ifndef Bruxism_hpp
#define Bruxism_hpp

#include <stdio.h>
class Bruxism
{
public:
    
    Bruxism(const float s2, const float s3, const float s4, const float a1, const float a2, const float a3, const float rem); //constructor
    ~Bruxism(); //destructor
    
    float bruxRun(int seconds, float& sleepOldVal, float& sleepNewVal, float& durationOldVal, float& durationNewVal);
    
    
private:
    
    int bruxData[16];
    float bruxSleepType[16];
    float bruxEventDuration[16];
    


    
};


#endif /* Bruxism_hpp */
