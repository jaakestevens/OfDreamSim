//
//  Control.hpp
//  FeverDream
//
//  Created by Jake on 29/03/2023.
//

#ifndef Control_hpp
#define Control_hpp

#include <stdio.h>
class Control
{
public:
    
    Control(const float s2, const float s3, const float s4, const float a1, const float a2, const float a3, const float rem); //constructor
    ~Control(); //destructor
    
    float controlRun(int seconds, float& sleepOldVal, float& sleepNewVal, float& durationOldVal, float& durationNewVal);
    
    
private:
    
    int controlData[16];
    float controlSleepType[16];
    float controlEventDuration[16];
    


    
};


#endif /* Bruxism_hpp */
