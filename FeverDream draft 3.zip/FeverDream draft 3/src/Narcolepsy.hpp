//
//  Narcolepsy.hpp
//  FeverDream
//
//  Created by Jake on 29/03/2023.
//

#ifndef Narcolepsy_hpp
#define Narcolepsy_hpp

#include <stdio.h>
class Narcolepsy
{
public:
    
    Narcolepsy(const float s2, const float s3, const float s4, const float a1, const float a2, const float a3, const float rem); //constructor
    ~Narcolepsy(); //destructor
    
    float narcRun(int seconds, float& sleepOldVal, float& sleepNewVal, float& durationOldVal, float& durationNewVal);
    
    
private:
    
    int narcData[16];
    float narcSleepType[16];
    float narcEventDuration[16];
    


    
};


#endif /* Bruxism_hpp */
