//
//  Data Processesor.cpp
//  FeverDream
//
//  Created by Jake on 29/03/2023.
//

#include "RBD.hpp"
#include <iostream>
using namespace std;


RBD::RBD(const float s2, const float s3, const float s4, const float a1, const float a2, const float a3, const float rem)
{
    const float S2 = s2;
    const float S3 = s3;
    const float S4 = s4;
    const float A1 = a1;
    const float A2 = a2;
    const float A3 = a3;
    const float REM = rem;
    
    
    //Time values
    const int remSleepTimes[] = {0, 9, 39, 69, 99, 129, 159, 189, 219, 249, 265, 279, 309, 332, 339, 353}; //16
    
    for(int i = 0; i < 15; i++)
    {
        remData[i] = remSleepTimes[i];
    }
    //Sleep Value
    const float remSleepLevels[] = {REM,REM,REM,REM,REM,REM,REM,S2,REM,S2,A1,S2,S2,A1,S2,A1};
    
    for(int i = 0; i < 15; i++)
    {
        remSleepType[i] = remSleepLevels[i];
    }
    
    //event duration
    
    const float remDurations[] = {30,30,30,30,30,30,30,30,30,30,6,30,30,6,30,6};
    
    for(int i = 0; i < 15; i++)
    {
        remEventDuration[i] = remDurations[i];
    }
    
}
RBD::~RBD()
{
    
}
float RBD::remRun(int seconds, float& sleepOldVal, float& sleepNewVal, float& durationOldVal, float& durationNewVal)
{
        for(int i = 0; i < 15; i++)
        {
            if(remData[i] == seconds)
            {
                sleepNewVal = remSleepType[i];
                if(i > 0)
                {
                    sleepOldVal = remSleepType[i-1];
                }
                durationNewVal = remEventDuration[i];
                if(i > 0)
                {
                    durationOldVal = remEventDuration[i-1];
                }
            }
        }
};
    
