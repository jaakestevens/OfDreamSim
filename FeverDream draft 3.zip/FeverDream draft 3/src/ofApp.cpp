#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    
    ofResetElapsedTimeCounter();
    
    gui.setup();
    dreaming = false;
    typeSelected = false;
    
    uiAmount = 1;
    
    uiPos1 = 276;
    uiPos2 = -408;
    uiPos3 = -246;
    uiPos4 = 228;
    uiPos5 = 192;
    uiPos6 = -96;;
    
    uiDistance = 60;
    uiPoints = true;
    
    
    
    timerEnd = false;
    startTime = ofGetElapsedTimeMillis();
    
    ofSetBackgroundColor(0, 0, 0);
    ofSetFrameRate(60);
    
    mesh.setMode(OF_PRIMITIVE_LINES);
    
    sleepVal = 0.1f;
    durationVal = 0.1f;
    
    sleepOldVal = 0.f;
    sleepNewVal = 0.f;
    
    
    durationOldVal = 0.f;
    durationNewVal = 0.f;
    
    //Picture Seed
    oceanImg.load("Ocean.jpeg");
    cityImg.load("City.jpeg");
    snowImg.load("Snow.jpeg");
    greenImg.load("Green.jpeg");
    
    dreamChange(oceanImg);
        
}

//--------------------------------------------------------------
void ofApp::update(){
    
    //Scales sleep values from one to the next
    sleepVal += (sleepNewVal - sleepVal) * (stepAmount);
    durationVal += (durationNewVal - durationVal) * (stepAmount);
    
   
    //Mesh
    if(sleepVal < 0.4) //before the stage "a2"(slightly awake still)
    {
        ofSeedRandom(durationVal); //slows things down and creates a stuttering effect
    }else
    {
        ofSeedRandom(60);
    }
    mesh.clear();

    for(int i = 0; i < uiAmount; i++)
    {
        float speedAmount = ofMap(sleepVal, 0.f, 2.f, 0.98, 1.04); //Maps speed of particles
        
        ofVec3f position = ofVec3f(
                            ofMap(ofNoise(ofRandom(600 * speedAmount), ofGetElapsedTimef() * 0.006), 0, 1, uiPos1, uiPos2), //X
                            ofMap(ofNoise(ofRandom(600 * speedAmount), ofGetElapsedTimef() * 0.006), 0, 1, uiPos3, uiPos4), //Y
                                   ofMap(ofNoise(ofRandom(600 * speedAmount), ofGetElapsedTimef() * 0.006), 0, 1, uiPos5, uiPos6)); //Z

        mesh.addVertex(position);
        
        int indexRandomness = ofMap(sleepVal, 0.f, 1.8, 10, 1); //as the sleepValue increases, more of the photo weill be processed
        
        int randomIndex = ofRandom(colours.size() /indexRandomness);
        int scaledIndex = ofMap(sleepVal, 1.8, 1.925, 0, colours.size()); //Will analyse more of the picture as the dream increases
        
        int remAlpha = ofRandom(ofMap(durationVal, 15.f, 30.f, 0, 255)); //maps duration to the alpha of new vertexs created when in REM SLEEP
        
        int pixelIndex;
        int pixelAlpha;
        
        if(sleepVal >= 1.8 && sleepVal <= 1.81) //first transition
        {
            remTransition = true;
            pixelIndex = scaledIndex;
            mesh.addColor(ofColor(colours[pixelIndex][0],colours[pixelIndex][1],colours[pixelIndex][2], pixelAlpha));
        }else{
            remTransition = false;
        }
       
        
        if(sleepVal >= 1.81)
        {
            if((sleepVal > 1.86 && sleepVal < 1.863) || (sleepVal > 1.92 && sleepVal < 1.923))//increments
            {
                    
                    pixelIndex = scaledIndex;
                    
                    mesh.addColor(ofColor(colours[pixelIndex][0],colours[pixelIndex][1],colours[pixelIndex][2], pixelAlpha));
            }
            else{
                pixelIndex = randomIndex;
                }
            uiPos5 -= timeAsleep / ofGetFrameRate();
            pixelAlpha = remAlpha;
            
        }
        else
        {
            pixelIndex = randomIndex; //creates a flashing effect
            pixelAlpha = colours[pixelIndex][3];
            uiPos5 = 192;
            uiPos6 = -96;
        }
       
        
        mesh.addColor(ofColor(colours[pixelIndex][0],colours[pixelIndex][1],colours[pixelIndex][2], pixelAlpha));
    }

    
    for(int i = 0; i < mesh.getVertices().size(); i++)
    {
        auto position = mesh.getVertex(i);

        for(int j = 0; j < mesh.getVertices().size(); j++)
        {
            auto jdistance = mesh.getVertex(j);
            auto distance = glm::distance(position, jdistance); //checking distance from position and jdistance

            if(distance < uiDistance) //if they are close to each other
            {
                mesh.addIndex(i);
                mesh.addIndex(j);
                
            }
        }
    }
    
    if(seconds >= 300)
        {
            setup();
        }
    
    if(sleepType == 1)
    {
        brux.bruxRun(seconds,sleepOldVal,sleepNewVal,durationOldVal,durationNewVal);
        timeAsleep = 2.5;
    }
    if(sleepType == 2)
    {
        insom.insomRun(seconds,sleepOldVal,sleepNewVal, durationVal, durationNewVal);
        timeAsleep = 2.5;
    }
    if(sleepType == 3)
    {
        control.controlRun(seconds,sleepOldVal,sleepNewVal,durationOldVal,durationNewVal);
        timeAsleep = 1.1;
    }
    if(sleepType == 4)
    {
        narc.narcRun(seconds,sleepOldVal,sleepNewVal, durationVal, durationNewVal);
        timeAsleep = 6.15;
    }
    if(sleepType == 5)
    {
        rbd.remRun(seconds,sleepOldVal,sleepNewVal,durationOldVal,durationNewVal);
        timeAsleep = 1.56;
    }
    if(dreaming == false)
    {
        sleepVal = 0.f;
        durationVal = 0.f;
    }
    
}

//--------------------------------------------------------------
void ofApp::draw(){
    
    if(dreaming == false)
    {
        if(typeSelected == false) //Loading Screen
        {
            ofDrawBitmapString("The aim of this project is to provide a visual representation \n the sleep process, based off real-life data provided \n by the CAP Sleep Database. By selecting a participant the mesh onscreen will \n grow, shrink and move in relation to the stage of sleep the \n participant is in. The colour of the mesh is determined by the 'dream seed' \n where, the program will select random colours from the image provided. The \n level of randomness will also be affected by the stage of sleep. Enjoy! ", 10, 25);
            
            ofDrawBitmapString("Participant Selcted : ", ofGetWidth() * 0.45, ofGetHeight() * 0.6);
            ofDrawBitmapString(sleepType, ofGetWidth() * 0.63, ofGetHeight() * 0.6);
            
            ofDrawBitmapString("Welcome to the dream Simulator!", ofGetWidth() * 0.4, ofGetHeight() * 0.4);
            
            ofSetColor(230, 230, 255);
            ofDrawBitmapString("CONTAINS FLASHING LIGHTS", ofGetWidth() * 0.8, ofGetHeight() * 0.05);
            
            ofSetColor(255);
            ofDrawBitmapString("Please select the participant you wish to dream using keys 1-5 \n and then pressing 'r'", ofGetWidth() * 0.25, ofGetHeight() * 0.5);
            
            ofDrawBitmapString("1. Bruxism", ofGetWidth() * 0.05, ofGetHeight() * 0.75);
            ofDrawBitmapString("involuntary habitual \n grinding of \n the teeth", ofGetWidth() * 0.05, ofGetHeight() * 0.8);
            
            ofDrawBitmapString("2. Insomnia", ofGetWidth() * 0.25, ofGetHeight() * 0.75);
            ofDrawBitmapString("habitual sleeplesness \n inability to \n sleep", ofGetWidth() * 0.25, ofGetHeight() * 0.8);
            
            ofDrawBitmapString("3. N/A", ofGetWidth() * 0.45, ofGetHeight() * 0.75);
            ofDrawBitmapString("control subject \n with no known \n disorder", ofGetWidth() * 0.45, ofGetHeight() * 0.8);
            
            ofDrawBitmapString("4. Narcolepsy", ofGetWidth() * 0.65, ofGetHeight() * 0.75);
            ofDrawBitmapString("affects the brain's \n ability \n to control \n  sleep-wake \n cycles", ofGetWidth() * 0.65, ofGetHeight() * 0.8);
            
            ofDrawBitmapString("5. Rem Behavioural \n Disorder", ofGetWidth() * 0.85, ofGetHeight() * 0.75);
            ofDrawBitmapString("increased physical \n movements during \n sleep", ofGetWidth() * 0.85, ofGetHeight() * 0.8);
        }
        
        else if(typeSelected == true)
        {
            ofDrawBitmapString("Thanks for choosing!", ofGetWidth() * 0.4, ofGetHeight() * 0.4);
            
            ofDrawBitmapString("Now drag a jpeg of your choice onto the screen to begin the dream", ofGetWidth() * 0.25, ofGetHeight() * 0.45);
        }
    }
    
    if(dreaming == true)
        {
            ofDrawBitmapString("Press '1'", ofGetWidth() * 0.85, ofGetHeight() * 0.5 - 100);
            drawSeedImage(oceanImg, 0, -100);
            
            ofDrawBitmapString("Press '2'", ofGetWidth() * 0.85, ofGetHeight() * 0.5);
            drawSeedImage(cityImg, 0,0);
            
            ofDrawBitmapString("Press '3'", ofGetWidth() * 0.85, ofGetHeight() * 0.5 + 100);
            drawSeedImage(snowImg, 0,100);
           
            ofDrawBitmapString("Press '4'", ofGetWidth() * 0.85, ofGetHeight() * 0.5 + 200);
            drawSeedImage(greenImg, 0,200);
            
            ofDrawBitmapString("Press '5'", ofGetWidth() * 0.85, ofGetHeight() * 0.5 + 300);
            ofDrawBitmapString("(Your Seed)'", ofGetWidth() * 0.85, ofGetHeight() * 0.5 + 330);
            
            if(dragImage.size() > 0)
            {
                for(int i = 0; i < dragImage.size(); i++)
                {
                    drawSeedImage(dragImage[i], 0, 300);
                }
                
            }
            
            ofDrawBitmapString("Press the Spacebar to choose a new participant", ofGetWidth() * 0.45, ofGetHeight() * 0.95);
            
            time = ofGetElapsedTimeMillis() - startTime;
            seconds = (int)time / 1000;
            minutes = seconds / 60;
            
            
            
            ofSetColor(255);
            ofDrawBitmapString(seconds, ofGetWidth() * 0.52, 25);
            ofDrawBitmapString("/ 300", ofGetWidth() * 0.55, 25);
            ofDrawBitmapString("seconds", ofGetWidth() * 0.6, 25);
            
            ofDrawBitmapString(sleepVal, ofGetWidth() * 0.9, ofGetHeight() * 0.1);
            ofDrawBitmapString("Sleep Value", ofGetWidth() * 0.8, ofGetHeight() * 0.1);
            
            
            ofDrawBitmapString(durationVal, ofGetWidth() * 0.94, ofGetHeight() * 0.2);
            ofDrawBitmapString("Duration Value", ofGetWidth() * 0.8, ofGetHeight() * 0.2);
            
            if(remTransition)
            {
                ofSetColor(255, 0, 0);
                ofDrawBitmapString("REM Transition", ofGetWidth() * 0.1, 25);
            }
            if(sleepVal >= 1.81)
            {
                ofSetColor(255, 0, 0);
                ofDrawBitmapString("REM DREAMING", ofGetWidth() * 0.1, 25);
            }
            
            ofTranslate(ofGetWidth()/2, ofGetHeight()/2);
            ofSetColor(255);
            
            float sizeVal = ofMap(durationVal,0,30,4,3);
            
                if(uiPoints == true) //if true
                {
                    for(int i = 0; i < mesh.getVertices().size(); i++)
                    {
                        ofDrawSphere(mesh.getVertex(i),sizeVal); //puts a sphere with width and height 3
                    }
                }
            
            mesh.draw();
            
            //Mapping
            uiDistance = sleepVal * 100;
            uiAmount = sleepVal * 100;
            uiPos5 = ofMap(sleepVal, 2.f, 0.f, 300, 0);
            uiPos6 = ofMap(sleepVal,2.f, 0.f, -200, 400);
            
            
            if(sleepVal < 1.8)
            {
                uiPoints = true;
            }
            
            else if(sleepVal >= 1.8)
            {
                uiPoints = false;
            }
                
        }
        
    }

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
if (key == ' ')
{
    setup();
    
}
    if(dreaming == false)
    {
        if(key == '1')
        {
            sleepType = 1;
        }
        if(key == '2')
        {
            sleepType = 2;
        }
        if(key == '3')
        {
            sleepType = 3;
        }
        if(key == '4')
        {
            sleepType = 4;
        }
        if(key == '5')
        {
            sleepType = 5;
        }
        if(key == 'r' && sleepType > 0)//enter
        {
            
            typeSelected = true;
            std::cout<< typeSelected <<std::endl;
        }
    }
    if(dreaming)
    {
        if(key == '1')
        {
            dreamChange(oceanImg);
        }
        if(key == '2')
        {
            dreamChange(cityImg);
        }
        if(key == '3')
        {
            dreamChange(snowImg);
        }
        if(key == '4')
        {
            dreamChange(greenImg);
        }
    }
    
    
    if(key == '5' && dragImage.size() > 0)
    {
        for(int i = 0; i < dragImage.size(); i++)
        {
            dreamChange(dragImage[i]);
        }
    }
}

void ofApp::dreamChange(ofImage dreamSeed)
{
    
        colours.clear();
        
    ofPixels pixels = dreamSeed.getPixels();
        int w = dreamSeed.getWidth();
        int h = dreamSeed.getHeight();
    
    
        for (int i = 0; i < h; i++)
        {
            for(int j = 0; j < w; j++)
            {
                ofColor color = pixels.getColor(i, j);
                colours.push_back(color);
            }
        }
}

void ofApp::drawSeedImage(ofImage seed, int xOffset, int yOffset)
{
    //Max width and height
    int maxWidth = 100;
    int maxHeight = 100;
    
    //calculate new width and height while maintaining aspect ratio
    float imageRatio = (float)seed.getWidth() / (float)seed.getHeight();
    float newWidth, newHeight;
    if(imageRatio > 1.0f)
    {
        newWidth = maxWidth;
        newHeight = maxWidth / imageRatio;
    } else{
        newWidth = maxHeight * imageRatio;
        newHeight = maxHeight;
    }
    
    seed.resize(newWidth, newHeight);
    
    int x = ofGetWidth() * 0.95;
    int y = ofGetHeight() * 0.5;
    
    seed.draw(x + xOffset,y + yOffset);
}
//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
       
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
   
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){
    if(dragInfo.files.size() > 0 && typeSelected == true)
    {
        dragImage.assign(dragInfo.files.size(), ofImage());
        for(int i = 0; i < dragInfo.files.size(); i++)
        {
            dragImage[i].load(dragInfo.files[i]);
            if(dreaming == false)
            {
                ofResetElapsedTimeCounter();
                dreaming = true;
            }
        }
    }
}


