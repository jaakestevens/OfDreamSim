#pragma once

#include "Insomnia.hpp"
#include "Bruxism.hpp"
#include "Control.hpp"
#include "Narcolepsy.hpp"
#include "RBD.hpp"

#include "ofMain.h"
#include "ofxGui.h"


class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
        void dreamChange(ofImage dreamseed);
        void drawSeedImage(ofImage seed, int xOffset, int yOffset);
        void dreamSelection();
    
    
    
        //Mesh
        ofMesh mesh;
    
        ofParameter <float> uiAmount; //amount on screen 3-100
        ofParameter <float> uiPos1;
        ofParameter <float> uiPos2;
        ofParameter <float> uiPos3;
        ofParameter <float> uiPos4;
        ofParameter <float> uiPos5;
        ofParameter <float> uiPos6;
        ofParameter<float> uiDistance;
        ofParameter<bool> uiPoints;
        ofParameter<int> mode;
    ofParameter<int> seed;
    //Image
        ofImage oceanImg;
        ofImage cityImg;
        ofImage greenImg;
        ofImage snowImg;
    
    vector<ofImage> dragImage;
    
    std::vector<ofColor> colours;
    
        //ofImage dreamSeed;
    
        int dream;
        int w, h;
        
    //GUI
        ofxPanel gui;
    
    //Timer
        ofTimer timer;
        float startTime;
        bool timerEnd;
        ofParameter<float> endTime;
    
    unsigned long elapsedDreamTime = 0;
        float time;
        int seconds;
        int minutes;
    
        //Current Values
        float sleepVal;
        float durationVal;
        //Speed of increase
        float stepAmount = 0.0006;
        
        //Values used for scaled
        float sleepOldVal;
        float sleepNewVal;
        float durationOldVal;
        float durationNewVal;
        float timeAsleep;
    
    
    
     //Sleep values in accordance to neurocognitive theory
        float s2 = 1.1f; //S = deeper sleep
        float s3 = 1.3f;
        float s4 = 1.5;
        float a1 = 0.1; // A = lighter sleep
        float a2 = 0.4;
        float a3 = 0.7;
        float rem = 2.0f; // REM sleep
    
    
        //Participants
    class Bruxism brux{s2,s3,s4,a1,a2,a3,rem};
       
    class Insomnia insom{s2,s3,s4,a1,a2,a3,rem};
        
    class Control control{s2,s3,s4,a1,a2,a3,rem};
        
    class Narcolepsy narc{s2,s3,s4,a1,a2,a3,rem};
        
    class RBD rbd{s2,s3,s4,a1,a2,a3,rem};
    
        
        ofParameter<bool> dreaming;
        ofParameter<int> sleepType = 0;
        ofParameter<bool> typeSelected;
    
    bool remTransition;
};

