//
//  Data Processesor.cpp
//  FeverDream
//
//  Created by Jake on 29/03/2023.
//

#include "Bruxism.hpp"
#include <iostream>
using namespace std;


Bruxism::Bruxism()
{
    const float S2 = 2.0f;
    const float S3 = 3.0f;
    const float S4 = 4.f;
    const float A1 = 0.2f;
    const float A2 = 0.5f;
    const float A3 = 0.1f;
    const float REM = 5.f;
    
    
    //Time values
    const int bruxSleepTimes[] = {0,46, 47, 86, 107, 137, 148, 167, 197, 208, 227, 245, 257, 287, 317, 327}; //16
    
    for(int i = 0; i < 15; i++)
    {
        bruxData[i] = bruxSleepTimes[i];
    }
    //Sleep Value
    const float bruxSleepLevels[] = {S2,S2,A3,A3,S2,S2,A2,S2,S2,A1,S2,S2,S2,A1,A1,S2};
    
    for(int i = 0; i < 15; i++)
    {
        bruxSleepType[i] = bruxSleepLevels[i];
    }
    
    //event duration
    
    const float bruxDurations[] = {30,30,13,15,30,30,11,30,30,11,30,7,30,30,30,30};
    
    for(int i = 0; i < 15; i++)
    {
        bruxEventDuration[i] = bruxDurations[i];
    }
    
}
Bruxism::~Bruxism()
{
    
}
float Bruxism::bruxRun(int seconds, float& sleepOldVal, float& sleepNewVal, float& durationOldVal, float& durationNewVal)
{
        for(int i = 0; i < 15; i++)
        {
            if(bruxData[i] == seconds)
            {
                sleepNewVal = bruxSleepType[i];
                if(i > 0)
                {
                    sleepOldVal = bruxSleepType[i-1];
                }
                durationNewVal = bruxEventDuration[i];
                if(i > 0)
                {
                    durationOldVal = bruxEventDuration[i-1];
                }
            }
        }
}


    
