//
//  Bruxism.hpp
//  FeverDream
//
//  Created by Jake on 29/03/2023.
//

#ifndef Bruxism_hpp
#define Bruxism_hpp

#include <stdio.h>
class Bruxism
{
public:
    
    Bruxism(); //constructor
    ~Bruxism(); //destructor
    
    float bruxRun(int seconds, float& sleepOldVal, float& sleepNewVal, float& durationOldVal, float& durationNewVal);
    
private:
    
    int bruxData[16];
    float bruxSleepType[16];
    float bruxEventDuration[16];
    


    
};


#endif /* Bruxism_hpp */
