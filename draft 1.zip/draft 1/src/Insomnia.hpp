//
//  Insomnia.hpp
//  FeverDream
//
//  Created by Jake on 29/03/2023.
//

#ifndef Insomnia_hpp
#define Insomnia_hpp

#include <stdio.h>
class Insomnia
{
public:
    
    Insomnia(); //constructor
    ~Insomnia(); //destructor
    
    float insomRun(int seconds, float& sleepOldVal, float& sleepNewVal, float& durationOldVal, float& durationNewVal);
    
private:
    
    int insomData[16];
    float insomSleepType[16];
    float insomEventDuration[16];

    
};


#endif /* Insomnia_hpp */
