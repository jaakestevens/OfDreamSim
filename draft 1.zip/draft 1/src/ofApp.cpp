#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    gui.setup();
    gui.add(dreaming.set("Dreaming", false, false, true));
    gui.add(sleepType.set("SleepType", 1, 1, 5));
    
    gui.add(uiAmount.set("Amount", 30, 3, 100));
    gui.add(mode.set("mode", 1,0,1));
    
    gui.add(seed.set("seed", 1, 1, 4));
    
    gui.add(uiPos1.set("Pos 1", 276, -600, 600));//width
    gui.add(uiPos2.set("Pos 2", -408, -600, 600));

    gui.add(uiPos3.set("Pos 3", -246, -600, 600));//height
    gui.add(uiPos4.set("Pos 4", 228, -600, 600));

    gui.add(uiPos5.set("Pos 5", 288, -600, 600));//depth
    gui.add(uiPos6.set("Pos 6", -96, -600, 600));
    
    gui.add(uiDistance.set("distance", 60,3,100));
    gui.add(uiPoints.set("points", true,false,true));

    
    
    timerEnd = false;
    startTime = ofGetElapsedTimeMillis();
    
    ofSetBackgroundColor(0, 0, 0);
    ofSetFrameRate(60);
    
    mesh.setMode(OF_PRIMITIVE_LINES);
    
    sleepVal = 0.1f;
    durationVal = 0.1f;
    
    sleepOldVal = 0.f;
    sleepNewVal = 0.f;
    
    
    durationOldVal = 0.f;
    durationNewVal = 0.f;
    
    //Picture Seed
    oceanImg.load("Ocean.jpeg");
    cityImg.load("City.jpeg");
    snowImg.load("Snow.jpeg");
    greenImg.load("Green.jpeg");
    
    dreamChange(cityImg);
        
}

//--------------------------------------------------------------
void ofApp::update(){
    
    sleepVal += (sleepNewVal - sleepVal) * stepAmount;
    
    durationVal += (durationNewVal - durationVal) * (stepAmount * 6);
    
    //Mesh
    if(sleepVal < 1)
    {
        ofSeedRandom(durationVal); //slows things down
    }else
    {
        ofSeedRandom(60);
    }
    mesh.clear();
    
    ofPrimitiveMode modeArrays[] = {OF_PRIMITIVE_LINES, OF_PRIMITIVE_TRIANGLE_STRIP};

    for(int i = 0; i < uiAmount; i++)
    {
        float speedAmount = ofMap(sleepVal, 0.f, 2.f, 0.99, 1.02);
        
        ofVec3f position = ofVec3f(
                            ofMap(ofNoise(ofRandom(600 * speedAmount), ofGetElapsedTimef() * 0.006), 0, 1, uiPos1, uiPos2), //X
                            ofMap(ofNoise(ofRandom(600 * speedAmount), ofGetElapsedTimef() * 0.006), 0, 1, uiPos3, uiPos4), //Y
                                   ofMap(ofNoise(ofRandom(600 * speedAmount), ofGetElapsedTimef() * 0.006), 0, 1, uiPos5, uiPos6)); //Z

        mesh.addVertex(position);
        
        int randomIndex = ofRandom(colours.size());
        
        //std::cout<<colours[randomIndex]<<std::endl;
        
        mesh.addColor(ofColor(colours[randomIndex][0],colours[randomIndex][1],colours[randomIndex][2], colours[randomIndex][3]));
    }

    for(int i = 0; i < mesh.getVertices().size(); i++)
    {
        auto position = mesh.getVertex(i);

        for(int j = 0; j < mesh.getVertices().size(); j++)
        {
            auto jdistance = mesh.getVertex(j);
            auto distance = glm::distance(position, jdistance); //checking distance from position and jdistance

            if(distance < uiDistance) //if they are close to each other
            {
                mesh.addIndex(i);
                mesh.addIndex(j);
            }
        }
    }
    
    if(dreaming == false)
    {
        sleepVal = 0.f;
        durationVal = 0.f;
    }
    
    
}

//--------------------------------------------------------------
void ofApp::draw(){
    gui.draw();
    
    drawSeedImage(oceanImg, 0);
    drawSeedImage(cityImg, 100);
    drawSeedImage(snowImg, 200);
    drawSeedImage(greenImg, 300);
    
    
    float time;
    int seconds;
    int minutes;
        
    if(dreaming == true)
    {
        time = ofGetElapsedTimeMillis() - startTime;
        seconds = (int)time / 1000;
        minutes = seconds / 60;
    }else
    {
        time = 0;
        seconds = 0;
        minutes = 0;
    }
    
    //Time calculations
    
    ofSetColor(255);
    ofDrawBitmapString(seconds, ofGetWidth() / 2, 25);
    ofDrawBitmapString("seconds", ofGetWidth() / 1.9, 25);
    
    ofDrawBitmapString(minutes, ofGetWidth() / 3, 25);
    ofDrawBitmapString("minutes", ofGetWidth() / 2.8, 25);
    
    
    //start at 0
    if(ofGetElapsedTimeMillis() < 1000)
    {
        minutes = 0;
        ofDrawBitmapString(minutes, ofGetWidth() / 3, 25);
        
    }
    
    
    if(sleepType == 1)
    {
        brux.bruxRun(seconds,sleepOldVal,sleepNewVal,durationOldVal,durationNewVal);
        timeAsleep = 2.5;
    }
    if(sleepType == 2)
    {
        insom.insomRun(seconds,sleepOldVal,sleepNewVal, durationVal, durationNewVal);
        timeAsleep = 2.5;
    }
    
    ofDrawBitmapString(sleepVal, ofGetWidth() * 0.9, ofGetHeight() * 0.1);
    ofDrawBitmapString("Sleep Value", ofGetWidth() * 0.8, ofGetHeight() * 0.1);
    
    
    ofDrawBitmapString(durationVal, ofGetWidth() * 0.94, ofGetHeight() * 0.2);
    ofDrawBitmapString("Duration Value", ofGetWidth() * 0.8, ofGetHeight() * 0.2);
    
    ofTranslate(ofGetWidth()/2, ofGetHeight()/2);
    ofSetColor(255);
    
    float sizeVal = ofMap(durationVal,0,30,4,3);
    
    if(uiPoints == true) //if true
    {
        for(int i = 0; i < mesh.getVertices().size(); i++)
        {
            ofDrawSphere(mesh.getVertex(i),sizeVal); //puts a sphere with width and height 3
        }
    }
    if(dreaming == true)
    {
        mesh.draw();
    }
    
    //Mapping
    uiDistance = sleepVal * 100;
    uiAmount = sleepVal * 100;
    uiPos6 = ofMap(sleepVal,0.f, 2.f, -100, 400);
    
    
    if(seconds > 500)
    {
        setup();
    }
}


//--------------------------------------------------------------
void ofApp::keyPressed(int key){
if (key == ' ')
{
    setup();
    timerEnd = false;
    startTime = ofGetElapsedTimeMillis();
}
    if(key == '1')
    {
        dreamChange(oceanImg);
    }
    if(key == '2')
    {
        dreamChange(cityImg);
    }
    if(key == '3')
    {
        dreamChange(snowImg);
    }
    if(key == '4')
    {
        dreamChange(greenImg);
    }
}

void ofApp::dreamChange(ofImage dreamSeed)
{
    
        colours.clear();
        
    ofPixels pixels = dreamSeed.getPixels();
        int w = dreamSeed.getWidth();
        int h = dreamSeed.getHeight();
    
    
        for (int i = 0; i < h; i++)
        {
            for(int j = 0; j < w; j++)
            {
                ofColor color = pixels.getColor(i, j);
                colours.push_back(color);
            }
        }
}

void ofApp::drawSeedImage(ofImage seed, int yOffset)
{
    //Max width and height
    int maxWidth = 100;
    int maxHeight = 100;
    
    //calculate new width and height while maintaining aspect ratio
    float imageRatio = (float)seed.getWidth() / (float)seed.getHeight();
    float newWidth, newHeight;
    if(imageRatio > 1.0f)
    {
        newWidth = maxWidth;
        newHeight = maxWidth / imageRatio;
    } else{
        newWidth = maxHeight * imageRatio;
        newHeight = maxHeight;
    }
    
    seed.resize(newWidth, newHeight);
    
    int x = ofGetWidth() * 0.95;
    int y = ofGetHeight() * 0.5;
    
    seed.draw(x,y + yOffset);
}
//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
       
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
   
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}


