#pragma once

#include "Insomnia.hpp"
#include "Bruxism.hpp"

#include "ofMain.h"
#include "ofxGui.h"


class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
        void dreamChange(ofImage dreamseed);
    void drawSeedImage(ofImage seed, int yOffset);
    
    
    
        //Mesh
        ofMesh mesh;
    
        ofParameter <float> uiAmount; //amount on screen 3-100
        ofParameter <float> uiPos1;
        ofParameter <float> uiPos2;
        ofParameter <float> uiPos3;
        ofParameter <float> uiPos4;
        ofParameter <float> uiPos5;
        ofParameter <float> uiPos6;
        ofParameter<float> uiDistance;
        ofParameter<bool> uiPoints;
        ofParameter<int> mode;
    ofParameter<int> seed;
    //Image
        ofImage oceanImg;
        ofImage cityImg;
        ofImage greenImg;
        ofImage snowImg;
    
    std::vector<ofColor> colours;
    
        //ofImage dreamSeed;
    
        int dream;
        int w, h;
        
    //GUI
        ofxPanel gui;
    
    //Timer
        ofTimer timer;
        float startTime;
        bool timerEnd;
        ofParameter<float> endTime;
    
        //Current Values
        float sleepVal;
        float durationVal;
        //Speed of increase
        float stepAmount = 0.0006;
        
        //Values used for scaled
        float sleepOldVal;
        float sleepNewVal;
        float durationOldVal;
        float durationNewVal;
        
        
        float timeAsleep;
    
        class Bruxism brux;
        class Insomnia insom;
        
        ofParameter<bool> dreaming;
        ofParameter<int> sleepType;
		
};

