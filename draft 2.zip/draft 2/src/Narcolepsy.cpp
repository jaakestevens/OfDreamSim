//
//  Data Processesor.cpp
//  FeverDream
//
//  Created by Jake on 29/03/2023.
//

#include "Narcolepsy.hpp"
#include <iostream>
using namespace std;


Narcolepsy::Narcolepsy(const float s2, const float s3, const float s4, const float a1, const float a2, const float a3, const float rem)
{
    const float S2 = s2;
    const float S3 = s3;
    const float S4 = s4;
    const float A1 = a1;
    const float A2 = a2;
    const float A3 = a3;
    const float REM = rem;
    
    //Time values
    const int narcSleepTimes[] = {0, 5, 13, 43, 46, 73, 103, 132, 133, 163, 166, 180, 193, 223, 253, 276}; //16
    
    for(int i = 0; i < 15; i++)
    {
        narcData[i] = narcSleepTimes[i];
    }
    //Sleep Value
    const float narcSleepLevels[] = {S2,A3,S2,S2,A2,S2,S2,A1,S2,S3,A1,A1,S3,S3,S3,A1};
    
    for(int i = 0; i < 15; i++)
    {
        narcSleepType[i] = narcSleepLevels[i];
    }
    
    //event duration
    
    const float narcDurations[] = {30,20,30,30,13,30,30,8,30,30,5,10,30,30,30,11};
    
    for(int i = 0; i < 15; i++)
    {
        narcEventDuration[i] = narcDurations[i];
    }
    
}
Narcolepsy::~Narcolepsy()
{
    
}
float Narcolepsy::narcRun(int seconds, float& sleepOldVal, float& sleepNewVal, float& durationOldVal, float& durationNewVal)
{
        for(int i = 0; i < 15; i++)
        {
            if(narcData[i] == seconds)
            {
                sleepNewVal = narcSleepType[i];
                if(i > 0)
                {
                    sleepOldVal = narcSleepType[i-1];
                }
                durationNewVal = narcEventDuration[i];
                if(i > 0)
                {
                    durationOldVal = narcEventDuration[i-1];
                }
            }
        }
};
    
