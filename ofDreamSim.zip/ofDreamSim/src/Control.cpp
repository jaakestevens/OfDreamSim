//
//  Data Processesor.cpp
//  FeverDream
//
//  Created by Jake on 29/03/2023.
//

#include "Control.hpp"
#include <iostream>
using namespace std;


Control::Control(const float s2, const float s3, const float s4, const float a1, const float a2, const float a3, const float rem)
{
    const float S2 = s2;
    const float S3 = s3;
    const float S4 = s4;
    const float A1 = a1;
    const float A2 = a2;
    const float A3 = a3;
    const float REM = rem;
    
    //Time values
    const int controlSleepTimes[] = {0, 12, 23, 42, 72, 102, 132, 156, 162, 174, 192, 199, 222, 265, 272, 277}; //16
    
    for(int i = 0; i < 15; i++)
    {
        controlData[i] = controlSleepTimes[i];
    }
    //Sleep Value
    const float controlSleepLevels[] = {A1,S4,A1,S4,S4,S4,S4,A1,S4,A1,S4,A1,S4,A1,S4,A2};
    
    for(int i = 0; i < 15; i++)
    {
        controlSleepType[i] = controlSleepLevels[i];
    }
    
    //event duration
    
    const float controlDurations[] = {6,30,11,30,30,30,30,8,30,9,30,4,30,30,7,30};
    
    for(int i = 0; i < 15; i++)
    {
        controlEventDuration[i] = controlDurations[i];
    }
    
}
Control::~Control()
{
    
}
void Control::controlRun(int seconds, float& sleepOldVal, float& sleepNewVal, float& durationOldVal, float& durationNewVal)
{
        for(int i = 0; i < 15; i++)
        {
            if(controlData[i] == seconds)
            {
                sleepNewVal = controlSleepType[i];
                if(i > 0)
                {
                    sleepOldVal = controlSleepType[i-1];
                }
                durationNewVal = controlEventDuration[i];
                if(i > 0)
                {
                    durationOldVal = controlEventDuration[i-1];
                }
            }
        }
};
    
