//
//  Data Processesor.cpp
//  FeverDream
//
//  Created by Jake on 29/03/2023.
//

#include "Insomnia.hpp"
#include <iostream>
using namespace std;


Insomnia::Insomnia(const float s2, const float s3, const float s4, const float a1, const float a2, const float a3, const float rem)
{
    const float S2 = s2;
    const float S3 = s3;
    const float S4 = s4;
    const float A1 = a1;
    const float A2 = a2;
    const float A3 = a3;
    const float REM = rem;

    //Time values
    const int insomSleepTimes[] = {0,40, 90, 128, 140, 170, 178, 200, 230, 260, 290, 320, 350, 380, 410, 460}; //16
    
    for(int i = 0; i < 15; i++)
    {
        insomData[i] = insomSleepTimes[i];
    }
    //Sleep Value
    const float insomSleepLevels[] = {A2,S3,S3,A3,S2,S2,A2,S2,S2,A3,0,0,0,0,0,0};
    
    for(int i = 0; i < 15; i++)
    {
        insomSleepType[i] = insomSleepLevels[i];
    }
    
    //event duration
    
    const float insomDurations[] = {17,30,30,21,30,30,22,30,30,30,30,30,30,30,30,30};
    
    for(int i = 0; i < 15; i++)
    {
        insomEventDuration[i] = insomDurations[i];
    }
    
}
Insomnia::~Insomnia()
{
    
}
void Insomnia::insomRun(int seconds, float& sleepOldVal, float& sleepNewVal, float& durationOldVal, float& durationNewVal)
{
    for(int i = 0; i < 15; i++)
    {
        if(insomData[i] == seconds)
        {
            sleepNewVal = insomSleepType[i];
           
            if(i > 0)
            {
                sleepOldVal = insomSleepType[i-1];
            }
            durationNewVal = insomEventDuration[i];
            
            if(i > 0)
            {
                durationOldVal = insomEventDuration[i-1];
            }
        }
    }
}


    
