//
//  REM.hpp
//  FeverDream
//
//  Created by Jake on 29/03/2023.
//

#ifndef RBD_hpp
#define RBD_hpp

#include <stdio.h>
class RBD
{
public:
    
    RBD(const float s2, const float s3, const float s4, const float a1, const float a2, const float a3, const float rem); //constructor, passes the dream level values
    ~RBD(); //destructor
    
    void remRun(int seconds, float& sleepOldVal, float& sleepNewVal, float& durationOldVal, float& durationNewVal);
    
    
private:
    
    int remData[16];
    float remSleepType[16];
    float remEventDuration[16];
    
};


#endif /* Bruxism_hpp */
